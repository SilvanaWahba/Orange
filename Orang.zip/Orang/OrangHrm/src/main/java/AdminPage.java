import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.*;

public class AdminPage {
	
	
public WebElement AddButton(WebDriver myBrowser){
	
	return myBrowser.findElement(By.cssSelector("button[class='oxd-button oxd-button--medium oxd-button--secondary']"));
}

public WebElement UserRole(WebDriver myBrowser){
	
	return myBrowser.findElement(By.cssSelector("div[class='oxd-select-text-input']"));
}

public WebElement DropDownOption(WebDriver myBrowser){
	
	return myBrowser.findElement(By.xpath("//div[@role='option'][contains(.,'Admin')]"));
}

public WebElement UserStatus(WebDriver myBrowser){
	
	return myBrowser.findElement(By.xpath("(//i[@class='oxd-icon bi-caret-down-fill oxd-select-text--arrow'])[2]"));
}

public WebElement DropDownOption2(WebDriver myBrowser){
	
	return myBrowser.findElement(By.xpath("//div[@role='option'][contains(.,'Enabled')]"));
}

public WebElement EmployeeSearch(WebDriver myBrowser){
	
	return myBrowser.findElement(By.cssSelector("input[placeholder='Type for hints...']"));
}

public WebElement EmployeeOption(WebDriver myBrowser){
	
	return myBrowser.findElement(By.xpath("//div[@role='listbox']"));
}

public WebElement Username(WebDriver myBrowser){
	
	return myBrowser.findElement(By.xpath("(//INPUT[@data-v-1f99f73c=''])[2]"));
}

public WebElement NewPassword(WebDriver myBrowser){
	
	return myBrowser.findElement(By.xpath("(//INPUT[@data-v-1f99f73c=''])[3]"));
}

public WebElement ConfirmPassword(WebDriver myBrowser){
	
	return myBrowser.findElement(By.xpath("(//INPUT[@data-v-1f99f73c=''])[4]"));
}

public WebElement SaveButton(WebDriver myBrowser){
	
	return myBrowser.findElement(By.cssSelector("button[type='submit']"));
}

}
