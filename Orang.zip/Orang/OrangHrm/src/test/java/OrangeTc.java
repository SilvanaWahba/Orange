import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.*;


public class OrangeTc {

    

//    @BeforeTest
//    public void waitingTime() throws InterruptedException {
//        Thread.sleep(300);
//
//    }
//
//    @BeforeMethod
//    public void setUp() {
//        myBrowser = new ChromeDriver();
//
//    }
//
//    @AfterSuite
//    public void tearDown() {
//        myBrowser.quit();
//    }

    WebDriver myBrowser;
    LoginPage login;
    AdminPage admin;

    @BeforeTest
    public void OpenBrowser() throws InterruptedException{
        myBrowser = new ChromeDriver();

        myBrowser.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
        myBrowser.manage().window().maximize();
        Thread.sleep(300);

	login = new LoginPage();
    }

    @Test
    public void ValidLogin() throws InterruptedException {


        login.UsernameField(myBrowser).sendKeys("Admin");
        login.PasswordField(myBrowser).sendKeys("admin123");
        login.SubmitButton(myBrowser).click();
        Thread.sleep(3000);

        // First Assertion
//        String ExpectedResult = "Dashboard";
//        String ActualResult = myBrowser.findElement(By.className("oxd-text oxd-text--h6 oxd-topbar-header-breadcrumb-module")).getText();
//        System.out.println("Actual = "+ ActualResult);
//        Assert.assertEquals(ActualResult, ExpectedResult);

        // Second Assertion
        Assert.assertEquals(myBrowser.getCurrentUrl(), "https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index");

    }
    

    @BeforeTest
    public void NavigateToAdmin() throws InterruptedException{

        myBrowser.findElement(By.cssSelector("span[class='oxd-text oxd-text--span oxd-main-menu-item--name']")).click();
        Thread.sleep(3000);

	admin = new AdminPage();
    }


    @Test
    public void CreateUser() throws InterruptedException {

	// Navigating to Admin menu.
	myBrowser.findElement(By.cssSelector("span[class='oxd-text oxd-text--span oxd-main-menu-item--name']")).click();
        Thread.sleep(3000);
	
// Click on Add button
        admin.AddButton(myBrowser).click();
        Thread.sleep(3000);

// Navigating to User Role dropdown list and select "Admin".
        admin.UserRole(myBrowser).click();
        Thread.sleep(1500);
        WebElement dropdownOption = admin.DropDownOption(myBrowser); 
        dropdownOption.click();

// Navigating to Status dropdown list and select "Enabled".
        admin.UserStatus(myBrowser).click();
        Thread.sleep(1500);
        WebElement dropdownUserStatus = admin.DropDownOption2(myBrowser);
        dropdownUserStatus.click();

// Navigating to Employee Name dropdown list and select "user".
        admin.EmployeeSearch(myBrowser).sendKeys("m");
        Thread.sleep(3000);
        WebElement dropdownEmployeeName = admin.EmployeeOption(myBrowser);
        dropdownEmployeeName.click();

// Navigate to Username field and insert "newUsername"
        admin.Username(myBrowser).sendKeys("newUser");

// Navigate to Password field and insert "User123"
        admin.NewPassword(myBrowser).sendKeys("User123");

// Navigate to Confirm Password field and insert "User123"
        admin.ConfirmPassword(myBrowser).sendKeys("User123");

// Navigate to Save button and click it
        admin.SaveButton(myBrowser).click();

        // First Assertion


    }


    @AfterTest
    public void QuitBrowser(){
        myBrowser.quit();
    }

    }